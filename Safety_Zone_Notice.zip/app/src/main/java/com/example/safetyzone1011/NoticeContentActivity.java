package com.example.safetyzone1011;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class NoticeContentActivity extends AppCompatActivity {
    TextView title,regId,content;
    String titles,regIds,contents;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_content);

        Button btnBack = findViewById(R.id.buttonBack);

        Intent intent = getIntent();
        titles = intent.getStringExtra("title");
        regIds = intent.getStringExtra("writer");
        contents = intent.getStringExtra("content");



        title = findViewById(R.id.textTitleSet);
        regId = findViewById(R.id.textRegId);
        content = findViewById(R.id.textContent);

        title.setText(titles);
        regId.setText(regIds);
        content.setText(contents);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}