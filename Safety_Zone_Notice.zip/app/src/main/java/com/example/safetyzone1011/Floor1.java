package com.example.safetyzone1011;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Floor1 extends AppCompatActivity {
    Button btnRegMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_floor1);

        btnRegMap = findViewById(R.id.buttonRegMap);
    }
}