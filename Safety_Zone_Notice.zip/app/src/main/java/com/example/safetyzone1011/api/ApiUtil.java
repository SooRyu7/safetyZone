package com.example.safetyzone1011.api;

import android.media.MediaTimestamp;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

public class ApiUtil {

    public static JSONObject callApi(String params, String type, String uri, Boolean isJson){

        HttpURLConnection conn = null;
        JSONObject responseJson = null;

        try {
            //URL 설정
            //개발서버 이용시 112.153.24.119:8070/api/v1

            if("GET".equals((type.toUpperCase())))
            {   String re = params.replace("\"","")
                    .replace("{","")
                    .replace(":","=")
                    .replace("}","")
                    .replace(",","&");
                uri+="?"+re;
            }

            URL url = new URL("http://192.168.219.103:8070/api/v1" + uri);



            // http connection 세팅
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(type);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            // TODO :: form data content type 확인 필요
            String contentType = isJson == true ? "application/json" : "xxx-form-data";
            conn.setRequestProperty("Content-Type", contentType);

            // TODO :: query로 호출 시 parameter 세팅
//            if("GET".equals(type.toUpperCase())){
//                conn.setDoOutput(true);
//                conn.setDoInput(true);
//                conn.getOutputStream().write(params.getBytes("UTF-8"));
//                uri +="?"+params.;
//            }

            // POST 시 설정
            if("POST".equals(type.toUpperCase())){
                conn.setDoOutput(true);
                conn.getOutputStream().write(
                        params.getBytes("UTF-8"));
            }
            else if("GET".equals(type.toUpperCase()))
            {
                conn.setDoInput(true);
            }




            // 결과 가공
            int responseCode = conn.getResponseCode();
            if (responseCode == 200) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
                responseJson = new JSONObject(sb.toString());

                // 응답 데이터
                System.out.println("responseJson :: " + responseJson);
            }else{
                throw new Exception();
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.disconnect();
        }

        return responseJson;
    }

//    public static void main(String[] args){
//
//        callApi("{\"accountId\": \"admin\", \"pwd\":\"1234\", \"push\":\"push_key\"}",
//                "POST",
//                    "/login.json",
//                true);
//
//    }

}
