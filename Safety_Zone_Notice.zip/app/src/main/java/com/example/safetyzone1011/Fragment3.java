package com.example.safetyzone1011;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
//행동요령
public class Fragment3 extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_fragment3, container, false);

        Button book1 = view.findViewById(R.id.book1);
        Button book2 = view.findViewById(R.id.book2);
        Button book3 = view.findViewById(R.id.book3);
        Button book4 = view.findViewById(R.id.book4);
        Button book5 = view.findViewById(R.id.book5);
        Button book6 = view.findViewById(R.id.book6);
        Button book7 = view.findViewById(R.id.book7);
        Button book8 = view.findViewById(R.id.book8);

        book1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.safekorea.go.kr/idsiSFK/neo/main_m/sot/fire.html"));
                startActivity(urlintent);
            }
        });

        book2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.safekorea.go.kr/idsiSFK/neo/main_m/sot/forestFire.html"));
                startActivity(urlintent);
            }
        });

        book3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.safekorea.go.kr/idsiSFK/neo/main_m/sot/building.html"));
                startActivity(urlintent);
            }
        });

        book4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.safekorea.go.kr/idsiSFK/neo/main_m/sot/explosion.html"));
                startActivity(urlintent);
            }
        });

        book5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.safekorea.go.kr/idsiSFK/neo/main_m/sot/rail.html"));
                startActivity(urlintent);
            }
        });

        book6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.safekorea.go.kr/idsiSFK/neo/main_m/sot/electricGas.html"));
                startActivity(urlintent);
            }
        });

        book7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.safekorea.go.kr/idsiSFK/neo/main_m/sot/suffering.html"));
                startActivity(urlintent);
            }
        });

        book8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.safekorea.go.kr/idsiSFK/neo/main_m/lit/traffic.html"));
                startActivity(urlintent);
            }
        });

        return view;
    }

}