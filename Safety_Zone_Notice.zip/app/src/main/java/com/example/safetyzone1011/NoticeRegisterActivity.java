package com.example.safetyzone1011;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.safetyzone1011.api.ApiUtil;

import org.json.JSONException;
import org.json.JSONObject;

public class NoticeRegisterActivity extends AppCompatActivity {
    TextView textRegId;
    EditText textTitle, textContent;

    Button buttonReg;
    String result;
    Boolean success;

    Fragment2 fragment2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_register);

        textContent = findViewById(R.id.textContent);
        textTitle = findViewById(R.id.textTitleSet);
        textRegId = findViewById(R.id.textRegId);

        buttonReg = findViewById(R.id.buttonReg);


        Intent intent = getIntent();
        String checkId = intent.getStringExtra("checkId");
        textRegId.setText(checkId);

    }



    public void register(View v) {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {

                JSONObject json = new JSONObject();
                try {
                    json.put("noticeTitle", textTitle.getText().toString());
                    json.put("noticeContent", textContent.getText().toString());
                    json.put("accountId", textRegId.getText().toString());

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                JSONObject response = ApiUtil.callApi(json.toString(),
                        "POST",
                        "/notice.json",
                        true);

                try {
                    if(response != null){
                        result = "공지사항 등록을 완료 하였습니다.";
                        success = Boolean.TRUE;
                    }
                    else{
                        result="공지사항 등록 실패.";
                        success = Boolean.FALSE;
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
                            if(success.equals(Boolean.TRUE)){
                                onBackPressed();
                            }

                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        th.start();
    }
}