package com.example.safetyzone1011;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MapRegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_register);
    }
}