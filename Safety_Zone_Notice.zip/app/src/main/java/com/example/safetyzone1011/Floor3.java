package com.example.safetyzone1011;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Floor3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_floor3);
    }
}