package com.example.safetyzone1011;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.safetyzone1011.api.ApiUtil;

import org.json.JSONException;
import org.json.JSONObject;

public class SignActivity extends AppCompatActivity {
    EditText et_id,et_pass,et_name;
    String result ="";
    String sign ="";
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(SignActivity.this, LoginActivity.class); //지금 액티비티에서 다른 액티비티로 이동하는 인텐트 설정
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);    //인텐트 플래그 설정
        startActivity(intent);  //인텐트 이동
        finish();   //현재 액티비티 종료
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);

        et_id = findViewById(R.id.et_id);
        et_pass = findViewById(R.id.et_pass);
        et_name = findViewById(R.id.et_name);
    }

    public void sign(View v) {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {

                JSONObject json = new JSONObject();
                try {
                    json.put("accountId", et_id.getText().toString());
                    json.put("pwd", et_pass.getText().toString());
                    json.put("accountName", et_name.getText().toString());

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                JSONObject response = ApiUtil.callApi(json.toString(),
                        "POST",
                        "/register.json",
                        true);

                try {
                    if(response != null){
                        result = et_name.getText().toString()+" 님 가입 환영합니다.";
                        sign = "OK";
                    }
                    else{
                        result="중복된 아이디가 있습니다.";
                        sign = "False";
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
                            if(sign.equals("OK")){
                                Intent intent = new Intent(SignActivity.this, LoginActivity.class);
                                startActivity(intent);
                                finish();
                            }

                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        th.start();
    }
}